# install pyautogui
import pyautogui

# size of screen
pyautogui.size()

# current postion of cursor
pyautogui.position() # x = first number (horizontal) y = second number (vertical)

# lets move the mouse!
pyautogui.moveTo(107, 99)

# move the moust slowly, so you can see it move.
pyautogui.moveTo(107, 99, duration=1.5)

# move the mouse relative to current position
pyautogui.moveRel(200, 0, duration=1.5) # added duration so I could see it moving

# click something
# find position of object by inputing command then hovering mouse and pressing enter
pyautogui.postion() # returned x=1257, y=151 (help button in IDLE)
pyautogui.click(1257, 151)

# clicks the mouse at current position
pyautogui.click()

# use command line to get current location of mouse LIVE, with RGB as well
# from the command line
pyautogui.displayMousePosition()
# this works in IDLE, but you get a call every second on a new line. This is not ideal!
