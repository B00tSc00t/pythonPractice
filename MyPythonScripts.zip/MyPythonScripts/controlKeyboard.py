# control the keyboard with python

import pyautogui
#Make sure the cursor is in the correct location
pyautogui.position() #find mouse position
pyautogui.click('coords of mouse') # position the cursor should be
pyautogui.typewrite('Info you want typed') # sends virtual key presses

pyautogui.typewrite('Info you want typed', interval=0.5) # interval makes typing a bit slower.

pyautogui.KEYBOARD_KEYS() # list of keys

pyautgui.hotkey('cntrl', 'c') # to copy...
