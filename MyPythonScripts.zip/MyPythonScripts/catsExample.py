print("How many cats do you have?")
numCats = input()
try:
    if int(numCats) >= 9:
        print("That's way too many cats!")
    else:
        print("That isn't too many cats!")
except ValueError:
    print("Input must be a number.")
