# install openpyxl

import openpyxl
import os
os.chdir('path to excel file') #os.chdir('C:\\Users\\sabor\\Desktop')

workbook = openpyxl.load_workbook('example.xlsx')

# video uses sheet = workbook.get_sheet_by_name('Sheet1'), which is depricated
sheet = (workbook['Sheet1'])

# if you don't know sheet names
workbook.get_sheet_names()

# values from a cell
cell = sheet['A1']
str(cell.value)

# or
str(sheet['A1'].value

# add some values from int cells together

sheet['C1'].value + sheet['C2'].value

for i in range(1, 8):
	print(i, sheet.cell(row=i, column=2).value)

# output
    ''' 1 Apples
2 Cherries
3 Pears
4 Oranges
5 Apples
6 Bananas
7 Strawberries
'''
