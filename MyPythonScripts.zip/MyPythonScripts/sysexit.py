import sys
print("Hello")
sys.exit()
print("Goodbye")
