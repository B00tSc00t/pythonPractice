# install python-docx
# import docx

import docx

# retrieve the document you want to review
d = docx.Document('C:\\Users\\sabor\\Desktop\\demo.docx') # path the document is in

# text related to specific paragraph in the document

d.paragraphs[0].text # first paragraph in the doc.

d.paragraphs[1].text # second paragraph in the doc.

p = d.paragraphs[1] # saving second paragraph to a variable

# paragraphs have 'runs', and each run is broken based on font changes
# get runs per paragraph
p = d.paragraphs[1] # assign p variable to second paragraph on doc
p.runs # return runs for the paragraph

# return each run in the paragraph
p.runs[0].text # and so on...

# can change runs in a paragraph

p.runs[3].underline = True
p.runs[3].text = 'italic and underlined.'

# save the changes
d.save('C:\\Users\\sabor\\Desktop\\demo1.docx') #path to destination

# can change styles
p.styles = 'Title' # changes the selected in the Title style

# create a blank document
d = docx.Document() # created inside python program

# add a paragraph to the doc.
d.add_paragraph('This is a paragraph')

# add to an existing paragraph
p.add_run('This is a new run.')



