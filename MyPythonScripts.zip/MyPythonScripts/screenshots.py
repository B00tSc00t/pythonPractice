import pyautogui

pyautogui.screenshot('c:\\screenshot_example.png') # create screenshot and save to set defined location

# image recognition

pyautogui.locateOnScreen('c:\\imageName.png') # returns a tuple of data where the image is and the width/height

# open calculator then find location of the 7 key
# he took a picture, then minimized the image and had gui move to the actual calc still open on the screen.

pyautogui.locateCenterOnScreen('c:\\calc7key.png')
pyautogui.moveTo(('x y of location'), duration=0.5) # move the mouse to the location of the 7 key
pyautogui.click('x y of key') # click the 7 key.


# github.com/asweigart/sushigoroundbot
# cool bot he built to play a sushi game / still in process

