#! python3

import re, pyperclip
# Create a regex for phone numbers

phoneRegex = re.compile(r'''
# 555-555-5555, 555-5555, (555) 555-5555, 555-5555 ext 12345, ext. 12345, x12345

(
(((\d\d\d)|(\(\d\d\d)))?       # area code (optional)
(\s|-)        # first hyphen
\d\d\d        # first three digits
-        # second hyphen
\d\d\d\d        # last four digits
(((ext(\.)?\s)|x)        # extension word-part (optional)
 (\d{2,5}))?       # extension number-part (optional)
)
''', re.VERBOSE)

# Create a rgex for email addresses
emailRegex = re.compile('''

[a-zA-Z0-9_.+]+        # name part
@                      # @ symbol
[a-zA-Z0-9_.+]+        # domain name

''', re.VERBOSE)

# Get the text off the clipboard
text = pyperclip.paste()

# Extact the email/phone from this text
extractedPhone = phoneRegex.findall(text)
extractedEmail = emailRegex.findall(text)

allPhoneNumbers = []
for phoneNumber in extractedPhone:
    allPhoneNumbers.append(phoneNumber[0])

# Copy the extracted email/phone to the clipboard
results = '\n'.join(allPhoneNumbers) + '\n' + '\n'.join(extractedEmail)
pyperclip.copy(results)
