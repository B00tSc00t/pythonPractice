name = 'Alice'
if name == 'Alice':
    print('Hi Alice')
print('Done')
