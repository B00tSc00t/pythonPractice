# install PyPDF2
# import PyPDF2
# import os

# if you don't change the working directory, then you have to type the path each time
os.chdir('path to excel file') #os.chdir('C:\\Users\\sabor\\Desktop')

# open the pdf
pdfFile = open('meetingminutes1.pdf', 'rb') # opens in binary mode

# open pdf reader
reader = PyPDF2.PdfFileReader(pdfFile)

reader.numPages

# which page to read
page = reader.getPage(0)

# extract text from selected page
page.extractText()

# extract all trext from document
for pageNum in range(reader.numPages):
	print(reader.getPage(pageNum).extractText())

# combine two documents to a single document
# open each file
pdf1File = open('meetingminutes1.pdf', 'rb')
pdf2File = open('meetingminutes2.pdf', 'rb')

# create reader for each file
reader1 = PyPDF2.PdfFileReader(pdf1File)
reader2 = PyPDF2.PdfFileReader(pdf2File)

# create pdf file writer, in Python
writer = PyPDF2.PdfFileWriter()

# loop through the first document
for pageNum in range(reader1.numPages):
	page = reader1.getPage(pageNum) # get each page number
	writer.addPage(page) # add blank page to the end

# same thing for second document
for pageNum in range(reader2.numPages):
	page = reader2.getPage(pageNum)
	writer.addPage(page)

# create new file to input data to
outputFile = open('combinedMinutes.pdf', 'wb') # wb to write binary
writer.write(outputFile)
outputFile.close(0) # close file
pdf1File.close()
pdf2File.close()
