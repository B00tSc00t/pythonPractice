import smtplib
conn = smtplib.SMTP('smtp.gmail.com', 587) # create connection to mail server. 587 is the port number for gmail.

# connect to the server
conn.ehlo()

# start tls encryption, so password is encrypted when sent
conn.starttls() # if returns code 220 then everything okay

# login to server
conn.login('saborick@gmail.com', 'xxxx') #gmail will have to allow less secure apps...

# send email
#From, TO, Subject, then \n (line breaks)to get to body. Type out body (all in one string)
conn.sendmail('saborick@gmail.com', 'saborick@gmail.com', 'Subject: Bye\n\nHi Rick, \nThis is an email direct from IDLE.\n\n-Rick')
#returns a dictionary '{}' of all emails that FAILED to send. If the dictionary is blank then the email(s) sent without issue.

# disconnect from the smtp server
conn.quit()
