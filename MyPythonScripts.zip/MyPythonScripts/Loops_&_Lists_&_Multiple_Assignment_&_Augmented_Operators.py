supplies = ['pens', 'books', 'computers', 'markers']
for i in range(len(supplies)):
    print('Index ' + str(i) + ' in suppliers is: ' + supplies[i])

# Multiple assignment

cat = ['fat', 'orange', 'loud']
# Instead of this...

# size = cat[0]
# color = cat[1]
# disposition = cat[2]

#Do this

size, color, disposition = cat

# Can also assign like this

size, color, disposition = 'skinny', 'black', 'quiet'

# Can also swap assignments

a = 'AAA'
b = 'BBB

# Like this
a, b = b, a

# Augmented assignment operators
# Instead of
spam = 42
spam = spam + 1

# Do this
spam += 1
