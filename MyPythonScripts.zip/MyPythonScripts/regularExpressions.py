import re

# instead of this
def isPhoneNumber(text):
    if len(text) != 12:
        return False # not phone number-sized
    for i in range(0, 3):
        if not text[i].isdecimal():
            return False # no area code
    if text[3] != '-':
        return False # missing dash
    for i in range(4, 7):
        if not text[i].isdecimal():
            return False # no first 3 digits
    if text[7] != '-':
        return False # missing second dash
    for i in range(8, 12):
        if not text[i].isdecimal():
            return False # missing last 4 digits
    return True


message = 'Call me at 43-324-9986 tomorrow, or at 43-342-9987'
foundNumber = False
for i in range(len(message)):
    chunck = message[i:i+12]
    if isPhoneNumber(chunck):
        print('Phone number found: ' + chunck)
        foundNumber = True
if not foundNumber:
    print('Could not find a phone number.')

# do this, using regular expressions

message = 'Call me at 433-34-9986 tomorrow, or at 433-42-9987'
phoneNumRegex = re.compile(r'\d\d\d-\d\d\d-\d\d\d\d')
mo = phoneNumRegex.search(message) # use .findall to find each occurrence of the data being searched.
print(mo.group())

