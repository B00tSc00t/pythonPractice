total = 0
for num in range(101):
    total = total + num
print(total)
