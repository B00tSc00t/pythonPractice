supplies = ['pens', 'books', 'computers', 'markers']
for i in range(len(supplies)):
    print('Index ' + str(i) + ' in suppliers is: ' + supplies[i])
