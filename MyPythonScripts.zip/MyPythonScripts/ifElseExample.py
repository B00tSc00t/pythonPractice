password = 'swordfish'
if password == 'swordfish':
    print('Access granted')
else:
    print('wrong password')
