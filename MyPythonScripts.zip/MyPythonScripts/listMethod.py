# List method Index
spam = ['hello', 'hi', 'howdy', 'hiya']
spam.index('hello')

# If you have duplicates in the list then index will return the first index it sees

# Use "append" to add to the end of the list

spam.append('yo')

# Can add to a specific spot in an index like this, which pushes everything else forward
spam.index(1, 'bye')

# Remove from a list with like this
spam.remove('bye')

# Using "del" will remove a specific index, not item
del spam[1]

# You can sort the list in alpha numeric order like this
spam.sort()

# Sort in reverse like this
spam.sort(reverse=True)

# Sorting is done with something called 'ASCII-betical' order.
# Uppercase comes first then lowercase.
# If it MUST be true order use this
spam(key=str.lower)
