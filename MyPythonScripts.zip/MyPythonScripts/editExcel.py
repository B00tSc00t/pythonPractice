# install openpyxl

import openpyxl
import os
os.chdir('path to excel file') #os.chdir('C:\\Users\\sabor\\Desktop')

# open a new workbook, inside python
wb = openpyxl.Workbook()

# sheet names
wb.get_sheet_names()

# add data to cells in sheet
sheet['A1'] = 42
sheet['A2'] = 'Hello'

# save workbook
wb.save('editingExcel.xlsx')

# add new sheet to file
sheet2 = wb.create_sheet()

# change sheet name with 'title' variable
sheet2.title = 'New Sheet Name'

# add new sheet to specific spot
wb.create_sheet(index=0, title='First Sheet')
