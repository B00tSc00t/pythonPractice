spam = 0
while spam < 5:
    print('Hello Spamie!')
    spam = spam + 1
