# install selenium through command line
# install geckodriver https://github.com/mozilla/geckodriver/releases

from selenium import webdriver

browser = webdriver.Firefox()
browser.get('htps://automatetheboringstuff.com')

# couldn't get the following command to work

elem = browser.find_element('') # video instructs 'find_element_by_css_selector', which is depricated

# click a link on the webpage and the following will work
browser.back()
browser.forward()
browser.refresh()
browser.quit() # to end session
