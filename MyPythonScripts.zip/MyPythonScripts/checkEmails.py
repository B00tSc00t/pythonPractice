# Instead of imaplib, which is built in we are using 3rd party modules
# install imapclient and pyzmail
import imapclient, pyzmail # cannot install pyzmail...

# connect to the server. 'ssl' is an encryption algorithm.
conn = imapclient.IMAPClient('imap.gmail.com', ssl=True)

# login
conn.login('saborick@gmail.com', 'xxxx')

# select a folder to look at
conn.select_folder('INBOX', readonly=True) #use read only so you don't mistakeny delete stuff!

# what to look for
UID = conn.search(['SINCE', '11-Feb-2022']) # all email UIDs 'since' given date

# translate UID to actual email
rawMessage = conn.fetch([23826], ['BODY[]', 'FLAGS']) #create variable for data. Provide UID you want to read

