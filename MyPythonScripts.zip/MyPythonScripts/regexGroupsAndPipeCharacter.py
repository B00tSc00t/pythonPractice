import re
# the following doesn't work, as expected, from this script.
# each line needs to be individually written directly in the command line.
phoneNumRegex = re.compile(r'(\d\d\d)-(\d\d\d-\d\d\d\d)') # using () around the data will create 'groups'.
mo = phoneNumRegex.search('My number is 432-654-2345')
mo.group() # to dsplay whichever group you want.

# if you want to show the () in the group(), withouth creating a group, then you have to cancel them out like this
rphoneNumRegex = re.compile(r'\(\d\d\d\) \d\d\d-\d\d\d\d')
mo = rphoneNumRegex.search('My number is (432) 654-2345')
mo.group()

# if you want to search for patters you would use the pipe | like so
# thie example will be for the work bat

batRegex = re.compile(r'Bat(man|mobile|copter|cave)')
mo = batRegex.search('Batman lives in a Batcave and drives a batmobile that was droppd off using the batcopter.')
mo.group()

# ? = match the preceeding group 0 or 1 times
catRegex = re.compile(r'Cat(wo)?man')# we are matching "wo", which can appear 0 or 1 time(s)
mo = catRegex.search('The adventures of Catwoman') # returns "Catwoman"
mo = catRegex.search('The adventures of Catman') # returns "Catman"
mo = catRegex.search('The adventures of Catwowowoman') # returns nothing because "wo" appears more than 1 time

# ? means 0 or 1, * means 0 or more, + means 1 or more times, {1} means exactly the number of times inside curly braces
# {3, 5} will search for a "Greedy" match, Regex will grab the highest request, which is 5 in this example
# to do a "non-greedy' match we put ? at the end, like this: {3, 5}?. This will return the firts match of 3.
