# Next is the 'shebang' line, exactly like it is

#! python3
import sys
print('Hello world!')
print(sys.argv) # Command line arguments can be read in the sys.argv list.


