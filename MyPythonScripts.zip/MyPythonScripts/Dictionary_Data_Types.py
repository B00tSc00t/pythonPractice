# Dictionary Data Type
# Value keys are set with curly braces {}
myCat = {'size': 'fat', 'color': 'red'}

# Access different parts of the value keys with "list" like this

list(myCat.keys()) # Keys
list(myCat.values()) # Value of the keys
list(myCat.items()) # Returns "two item tuples" of the key value pairs [{'size', 'fat']} ect...

# for a list of the keys like this
for k in myCat.keys():
    print(k) # returns size, color

# Use "get" to check if a value is in a key, so you don't crash your program

myCat.get('somevalue', '') # returns '' becuase somevalue isn't part of the keys

print('The cat is ' + str(myCat.get('ugly', 0)) + ' today.')
# returns The cat is 0 today, becasue ugly doesn't exist.

# Can use the "setdefualt" method to set the key:value as long as the key/value doesn't already exist.
# if the key already exists then setdefault does nothing.
