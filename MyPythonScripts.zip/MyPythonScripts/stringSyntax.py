# String Syntax
# \' Single quote
# \" Double quote
# \t Tab
# \n Newline (line break)
# \\ Backslash
