import pprint
message = 'It was a brght cold day in April, and the clocks were striking thirteen.'
count = {} # 'r': 12

for character in message.upper(): # add .upper() to change all chars to uppercase
    count.setdefault(character, 0)
    count[character] = count[character] + 1

print(count)
# use the pprint function to use pretty print, which can alphabetize the output.

pprint.pprint(count)

# Woohoo triple quotes! Use these to get past needing to escape out of different quote types
#for use with massive lines of text, if needed! ''' '''

# The pformat() function returns a string value {'': ,} of the output

pprint.pformat(count)
