import re

lyrics = '''12 Drummers Drumming
11 Pipers Piping
10 Lords a Leaping
9 Ladies Dancing
8 Maids a Milking
7 Swans a Swimming
6 Geese a Laying
5 Golden Rings
4 Calling Birds
3 French Hens
2 Turtle Doves
and a Partridge in a Pear Tree'''

xmasRegex = re.compile(r'\d+\s\w+') # looking for "d+" digits, "s" spaces, "w+" letters.

xmasRegex.findall(lyrics)
# returns the following
# ['12 Drummers', '11 Pipers', '10 Lords', '9 Ladies', '8 Maids', '7 Swans', '6 Geese', '5 Golden', '4 Calling', '3 French', '2 Turtle']

# Can create my owncharacter class with the following

vowelRegex = re.compile(r'[aeiouAEIOU]') # shorter than r'(a|e|i|o|u|A|E|I|O|U)' adding ^ before the expression that means DO NOT FIND r'(^a|e|i|o|u|A|E|I|O|U)'
